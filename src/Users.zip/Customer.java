
public class Customer {
	public Customer(String xUsername,String Password, String xName,String xEmail, double xBirthday)
	{
		
	}
	
	public void writeReview()
	{
		
	}
	public void viewYourReviews()
	{
		
	}
	public void editReview(String name)
	{
		
	}
	public void viewYourTickets()
	{
		
	}
}
