
public class Adminstrator {
	public void deleteEmployee(String employeeName)
	{
		employee.remove(employeeName);
	}
	public void createEmployee()
	{
		
	}
}
