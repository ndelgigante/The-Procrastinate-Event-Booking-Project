import java.util.*;
public class RegisteredUser {
	private String username;
	private String password;
	private String name;
	private String email;
	private double birthday;
	
}
