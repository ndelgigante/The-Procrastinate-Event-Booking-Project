
public class BaseUser {

}
